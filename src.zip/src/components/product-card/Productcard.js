import React from "react";
import Prodheading from "../product-heading/Prodheading";
import Finalprice from "../product-price/Finalprice";
import Review from "../review/Review";
import Bestseller from "../best-seller/Bestseller";
import Slider from "../splide-slide/Slider";
import { Link } from "react-router-dom";

function Productcard({
  title,
  newprice,
  margin,
  originalprice,
  discount,
  eta,
  rating,
  number,
  padding,
  width,
  index,
  options,
  list,
}) {
  return (
    <div
      className={`w-80 -xl:w-72 -sm:w-40 border-2 border-solid border-zinc-300 overflow-hidden rounded-lg -sm:border-none flex flex-col justify-center ${
        margin && "mr-4"
      }`}
    >
      <Link to="/">
        <div className="w-80 -xl:w-72 -sm:w-40 h-80 -xl:h-72 -sm:h-40 relative">
          <Slider options={options} list={list} borderRadius="-sm:rounded-xl" />
          <div className="absolute bottom-1 left-1">
            <Review
              rating={rating}
              number={number}
              padding={padding}
              width={width}
            />
          </div>
          {index === 0 && (
            <div className="absolute top-1 left-1">
              <Bestseller />
            </div>
          )}
        </div>
        <div className="flex flex-col text-left p-4 -sm:p-0">
          <div className="text-lg/none">
            <Prodheading heading={title} fontSize="text-base" />
          </div>
          <div className="text-lg/none mt-3 -xl:mt-2 -sm:mt-0 -sm:text-left">
            <Finalprice
              newprice={newprice}
              originalprice={originalprice}
              discount={discount}
              fontSizeNp="text-xl -xl:text-lg/none"
              fontSize="text-base"
              fontSizeDiscount="text-xl -xl:text-lg/none -sm:hidden"
            />
          </div>
          <div className="text-lg/none -sm:hidden">
            <div className="text-sm mt-3 -xl:mt-2 text-blue-400">
              <p>Earliest Delivery: {eta}</p>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}

export default Productcard;
