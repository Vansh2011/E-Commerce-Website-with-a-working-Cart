import React from "react";
import Producttext from "../product-text/Producttext";

function Hero() {
  return (
    <section className=" w-full flex justify-center items-center -xl:px-8">
      <Producttext />
    </section>
  );
}

export default Hero;
