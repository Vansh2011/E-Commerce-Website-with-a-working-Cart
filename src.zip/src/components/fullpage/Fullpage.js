import React from "react";
import Header from "../header/header";
import Hero from "../hero/Hero";
import Testimonial from "../Testimonial/Testimonial";
import Recentlyreviewed from "../recentlyreviewed/Recentlyreviewed";
import Youmaylike from "../youmayalsolike/Youmaylike";
import Whatothersviewing from "../whatothersview/Whatothersview";
import Banner from "../Banner/Banner";
import Readmorerender from "../readmore/Readmorerender";
import Footer from "../footer/Footer";

function Fullpage() {
  return (
    <div className="flex flex-col">
      <Header />
      <Hero />
      <Testimonial />
      <div className="invisible -sm:visible -sm:py-1 -sm:w-[22.5rem] -sm:border-3 -sm:border-solid -sm:mt-4 -sm:bg-zinc-100"></div>
      <Recentlyreviewed />
      <div className="invisible -sm:visible -sm:py-1 -sm:w-[22.5rem] -sm:border-3 -sm:border-solid -sm:mt-4 -sm:bg-zinc-100"></div>
      <Youmaylike />
      <div className="invisible -sm:visible -sm:py-1 -sm:w-[22.5rem] -sm:border-3 -sm:border-solid -sm:mt-4 -sm:bg-zinc-100"></div>
      <Whatothersviewing />
      <Banner />
      <Readmorerender />
      <Footer />
    </div>
  );
}

export default Fullpage;
