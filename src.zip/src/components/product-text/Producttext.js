import React from "react";
import Photodisplay from "../photo-wheel/photo-display";
import Prodheading from "../product-heading/Prodheading";
import Finalprice from "../product-price/Finalprice";
import Review from "../review/Review";
import Combos from "../Combos/Combos";
import Form from "../form/Form";
import Timeleft from "../time-left/Timeleft";
import Btnrender from "../button/Btnrender";
import Offerrender from "../offers/Offerrender";
import Aboutaccordion from "../accordion/Aboutaccordion";

function Producttext() {
  return (
    <div className="flex flex-col justify-center m-10 -lg:m-4 -sm:m-0">
      <div className="flex -sm:flex-col justify-center relative">
        <div className=" flex justify-center w-3/5 -sm:w-full max-h-96 mr-10 sticky top-32 -xl:top-20 -lg:w-[15rem] -sm:static mt-16 -xl:mt-8 mb-11 -xl:mb-4 -sm:mb-4 -sm:justify-center">
          <Photodisplay />
        </div>
        <div className="w-3/5 flex flex-col justify-center items-center overscroll-auto -lg:w-[10rem] -sm:w-80">
          <div className="-sm:w-[22.5rem] flex flex-col justify-center -sm:px-5">
            <div className="-sm:ml-5">
              <Prodheading
                heading="Love Red Roses Bouquets and Chocolate Cake"
                fontSize="text-xl"
              />
              <Finalprice
                newprice="₹1620"
                originalprice="₹1800"
                discount="10"
                fontSize="text-2xl"
                fontSizeNp="text-2xl"
                fontSizeDiscount="text-2xl"
              />
            </div>
            <div className="invisible -sm:visible -sm:w-[22.5rem] -sm:border-3 -sm:border-solid -sm:border-zinc-100"></div>
            <div className="-sm:absolute -sm:top-[21rem] -sm:left-8">
              <Review
                rating="4.5"
                number="295"
                review={true}
                padding="py-2 -sm:py-2"
                width="w-36 -sm:w-20"
              />
            </div>
            <Combos />
            <div className="invisible -sm:visible -sm:w-[22.5rem] -sm:border-4 -sm:border-solid -sm:border-zinc-100 -sm:mt-4"></div>
            <Form />
            <Timeleft />
            <Btnrender />
            <div className="invisible -sm:visible -sm:w-[22.5rem] -sm:border-4 -sm:border-solid -sm:border-zinc-100 -sm:mt-4"></div>
            <Offerrender />
            <div className="invisible -sm:visible -sm:w-[22.5rem] -sm:border-4 -sm:border-solid -sm:border-zinc-100 -sm:mt-4"></div>
            <Aboutaccordion />
            <div className="invisible -sm:visible -sm:w-[22.5rem] -sm:border-4 -sm:border-solid -sm:border-zinc-100 -sm:mt-2"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Producttext;
