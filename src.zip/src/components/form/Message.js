import React from "react";

function Message() {
  return (
    <div className="flex flex-col">
      <form className="flex flex-col -sm:pl-5 justify-center">
        <label className="text-left mt-6 mb-2  text-zinc-700 font-semibold text-xl">
          {" "}
          Message on Cake{" "}
        </label>
        <input
          type="text"
          className="text-l -sm:w-80 border-2 border-solid border-zinc-300  overflow-hidden rounded-xl flex justify-center items-center outline-none p-2 focus:border-black"
          placeholder="Message on Cake"
          maxLength="25"
        />
      </form>
    </div>
  );
}

export default Message;
