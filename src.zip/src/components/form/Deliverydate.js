import React from "react";

function Deliverydate() {
  return (
    <div className="flex flex-col -sm:hidden">
      <form className="flex flex-col">
        <label className="text-left mt-6 mb-2">
          Select Delivery Date & Time Slot
        </label>
        <input
          type="date"
          className="text-l border-2 border-solid border-zinc-300  overflow-hidden rounded-xl flex items-center outline-none p-2 focus:border-black"
          placeholder="Select Delivery Date and Time Slot"
        />
      </form>
    </div>
  );
}

export default Deliverydate;
