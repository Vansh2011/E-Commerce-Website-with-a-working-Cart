import "./App.css";
import Fullpage from "./components/fullpage/Fullpage";

function App() {
  return (
    <div className="App">
      <Fullpage />
    </div>
  );
}

export default App;
