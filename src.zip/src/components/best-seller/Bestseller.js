import React from "react";

function Bestseller() {
  return (
    <div>
      <p className="uppercase text-white bg-zinc-600 px-2 text-sm">
        Best seller
      </p>
    </div>
  );
}

export default Bestseller;
