import React from "react";
import Navbar from "../navbar/navbar";
import Dropdownanchor from "../dropdownmenu/dropdownanchor";

function Header() {
  return (
    <header className="-sm:hidden">
      <Navbar />
      <Dropdownanchor />
    </header>
  );
}

export default Header;
