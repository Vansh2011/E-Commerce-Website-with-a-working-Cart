import React from "react";

function Textheading({ heading, fontSize, padding }) {
  return (
    <div className="text-left">
      <p className="font-bold text-left text-xl mt-8 mb-2 capitalize">
        {heading}
      </p>
    </div>
  );
}

export default Textheading;
